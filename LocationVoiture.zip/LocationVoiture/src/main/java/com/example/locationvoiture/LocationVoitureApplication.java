package com.example.locationvoiture;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
/*
* @author Kachach Mohamed
* 13-02-2023
* SDK 18
* JDK-18.0.1.1
* Port : 8085
* Application.properties: a changer / to change
* */
@SpringBootApplication
public class LocationVoitureApplication {

    public static void main(String[] args) {
        SpringApplication.run(LocationVoitureApplication.class, args);
    }

}
